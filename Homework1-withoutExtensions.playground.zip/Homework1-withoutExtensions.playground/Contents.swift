import Foundation

class Figure{
  var name: String {
    return "Figure"
  }
  var cornerRadius: Int {
    return 0
  } //количество углов по условию
  
}
protocol FourCorners{
  var length: Double {get}
  var width: Double {get}
  var perimeter: Double {get}
}
extension FourCorners{
  var perimeter: Double {
    return 2 * (length + width)
  }
}

class Triangle: Figure{
  override var name: String{
    return self.name
  }
  override var cornerRadius: Int{
    return self.cornerRadius
  }
  var footing: Double
  var height: Double
  init(name: String, cornerRadius: Int, footing: Double, height: Double){
    self.footing = footing
    self.height = height
    }
  func square() -> Double{
    return self.footing * self.height / 2
  }
}

class Сircle: Figure{
  override var name: String{
    return self.name
  }
  override var cornerRadius: Int{
    return self.cornerRadius
  }
  var radius: Double
  init(name: String, cornerRadius: Int, radius: Double){
    self.radius = radius
  }
  func square() -> Double{
    return Double.pi * pow(self.radius,2)
  }
}

class Rectangle: Figure, FourCorners{
  override var name: String{
    return self.name
  }
  override var cornerRadius: Int{
    return self.cornerRadius
  }
  var length: Double
  var width: Double
  init(name: String, cornerRadius: Int, length: Double, width: Double){
    self.length = length
    self.width = width
  }
  func square() -> Double{
    return self.length * self.width
  }
}


var t1 = Triangle(name: "Triangle1", cornerRadius: 3, footing: 10, height: 10)
print(t1.square())

var c1 = Сircle(name: "Circle1", cornerRadius: 0, radius: 4.5)
print(c1.square())

var r1 = Rectangle(name: "Rectangle1", cornerRadius: 4, length: 3, width: 4)
print(r1.square())
print(r1.perimeter)


