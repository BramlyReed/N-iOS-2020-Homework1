import Foundation

class Figure{
    var name: String
    var cornerRadius: Int //количество углов по условию
    init(name: String, cornerRadius: Int) {
        self.name = name
        self.cornerRadius = cornerRadius
    }
}
protocol FourCorners{
    var length: Double {get}
    var width: Double {get}
    var perimeter: Double {get set}
}

class Triangle: Figure{
    var footing: Double
    var height: Double
    init(name: String, cornerRadius: Int, footing: Double, height: Double){
        self.footing = footing
        self.height = height
        super.init(name: name, cornerRadius: cornerRadius)
    }
    func square() -> Double{
        return self.footing*self.height/2
    }
}

class Сircle: Figure{
    var radius: Double
    init(name: String, cornerRadius: Int, radius: Double){
        self.radius = radius
        super.init(name: name, cornerRadius: cornerRadius)
    }
    func square() -> Double{
        return Double.pi * pow(self.radius,2)
    }
}

class Rectangle: Figure, FourCorners{
    var length: Double
    var width: Double
    var perimeter: Double
    init(name: String, cornerRadius: Int, length: Double, width: Double){
        self.length = length
        self.width = width
        self.perimeter = 2*(self.length + self.width)
        super.init(name: name, cornerRadius: cornerRadius)
    }
    func square() -> Double{
        return self.length * self.width
    }
}

var t1 = Triangle(name: "Triangle1", cornerRadius: 3, footing: 10, height: 10)
print(t1.square())

var c1 = Сircle(name: "Circle1", cornerRadius: 0, radius: 4.5)
print(c1.square())

var r1 = Rectangle(name: "Rectangle1", cornerRadius: 4, length: 3, width: 4)
print(r1.square())

